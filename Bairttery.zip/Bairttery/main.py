
#---Setup---#
import RPi.GPIO as GPIO
import serial
import time

import VRelay
import CRelay



GPIO.setmode(GPIO.BCM)

#Relays
VRelayPin = 21 # Valve relay GPIO pin
CRelayPin = 16 # Compressor relay GPIO pin
relaylist = [VRelayPin, CRelayPin]

for item in relaylist:
    GPIO.setup(item, GPIO.OUT)

ser = serial.Serial('/dev/ttyACM0', 9600) # Connect to the serial port on the Arduino


#---Config--#
max_temp = 30
max_pressure = 230 #~2 bar

#---Arduino read function---#
def ReadArduino():
    ArduinoData = ser.readline().decode('utf-8').rstrip() # Read the data from the Arduino and decode it
    global temperature, pressure
    temperature, pressure = map(float, ArduinoData.split(',')) # Split the data and turn it into two varibles
    round(temperature, 2)
def PrintSensors():
    print("| Temperature: ", temperature, end="  |  ") # Print the temperature and pressure of the compressor
    print("Pressure: ", pressure, " |")

#---Program---#
while True:
    try:
        ReadArduino()
        PrintSensors()
    except ValueError:
        print("Connection failed, retrying...")
        continue
    
    if temperature < max_temp and pressure < max_pressure: # Turn on the compressor when safe
        CRelay.ON()
    
    if temperature >= max_temp: # Turn off the compressor and start a timer
        CRelay.OFF()
        print("The compressor is overheated, it will turn on in 10 minutes.")
        
        countdown = 600 
        while countdown:
            mins, secs = divmod(countdown, 60)
            timer = f"{mins:02d}:{secs:02d}"
            print(timer, temperature, end="\r")
            time.sleep(1)
            countdown -= 1
            ReadArduino()
        print("The compressor will turn on again.")
    if pressure >= max_pressure: # Turn off the compressor,  then notify the user and ask wether the pressure should be released or not
        CRelay.OFF()
        print("Battery is charged.")
    
        print(pressure)
        start = input("Do you want to release the charge? Type Y to release.")
        if start == str("Y"): # Open the valve 
            print("Releasing pressure")
            while True:
                ReadArduino()
                PrintSensors()
                if pressure < 105:
                    VRelay.OFF()
                    break
                else:
                    VRelay.ON() 
        else:
            print("Release cancled")
        VRelay.OFF()
        
        