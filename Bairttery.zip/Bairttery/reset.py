# This script will terminate all running python scripts and reset all relays
import psutil
import RPi.GPIO as GPIO
from time import sleep

import VRelay
import CRelay

GPIO.setmode(GPIO.BCM)

#Relays 
VRelayPin = 21 # Valve relay GPIO pin
CRelayPin = 16 # Compressor relay GPIO pin
relaylist = [VRelayPin, CRelayPin]

for item in relaylist:
    GPIO.setup(item, GPIO.OUT)

VRelay.OFF()
CRelay.OFF()

def stop_process(name):
    for process in psutil.process_iter():
        if process.name() == name:
            process.terminate()
            print(f"Terminating {name} process with PID {process.pid}")
            
stop_process("python")  # terminate all Python processes


